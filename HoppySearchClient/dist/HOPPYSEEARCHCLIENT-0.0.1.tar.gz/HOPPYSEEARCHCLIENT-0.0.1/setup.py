from setuptools import setup, find_packages

VERSION = '0.0.1'
DESCRIPTION = 'Hoppy Search Client Package'

setup(
    name = "HOPPYSEEARCHCLIENT",
    version= VERSION,
    author= "Shivani Jagtap",
    author_email= "jagtapshivani996@gmail.com",
    description= DESCRIPTION,
    packages= find_packages(),
    install_requires = [],
    zip_safe = False
)